﻿namespace M220N.Models
{
    public class ViewerRating
    {
        public double Rating { get; set; }

        public int NumReviews { get; set; }

        public int Meter { get; set; }
    }
}
