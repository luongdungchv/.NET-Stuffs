﻿namespace M220N.Models
{
    public class Awards
    {
        public int Wins { get; set; }

        public int Nominations { get; set; }

        public string Text { get; set; }
    }
}
